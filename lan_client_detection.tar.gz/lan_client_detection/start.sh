#!/bin/bash
cppython lan_client_detection.py